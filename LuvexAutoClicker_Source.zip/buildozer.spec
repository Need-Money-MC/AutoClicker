[app]
title = Luvex Auto Clicker
package.name = luvexautoclicker
package.domain = org.luvex
source.dir = .
source.include_exts = py,kv,png,jpg,xml,java
version = 1.0
requirements = python3,kivy,pyjnius
orientation = portrait
fullscreen = 0

android.api = 35
android.minapi = 30
android.ndk = 27c
android.archs = arm64-v8a
android.add_src = src
android.permissions = SYSTEM_ALERT_WINDOW,FOREGROUND_SERVICE
android.extra_manifest_xml = %(source.dir)s/manifest_extra.xml

[buildozer]
log_level = 2
warn_on_root = 1
