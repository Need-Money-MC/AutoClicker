package org.luvex.autoclicker;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class FloatingButtonService extends Service {
    private WindowManager wm;
    private TextView bubble;
    private WindowManager.LayoutParams params;
    private int cps = 100;
    private float downX, downY, startX, startY;
    private boolean moved = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    private void createNotification() {
        String id = "luvex_clicker";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(id, "Auto Clicker",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, id) : new Notification.Builder(this);
        startForeground(7, b.setContentTitle("Luvex Auto Clicker")
                .setContentText("دکمه شناور آماده است")
                .setSmallIcon(android.R.drawable.ic_media_play).build());
    }

    private void showBubble() {
        bubble = new TextView(this);
        bubble.setText("●");
        bubble.setTextSize(34);
        bubble.setTextColor(0xFFFFFFFF);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF00B982));
        bubble.setBackground(getDrawable(android.R.drawable.btn_default));
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(76, 76, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 180; params.y = 420;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        moved = false;
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = params.x; startY = params.y;
                        float[] pos = center();
                        ClickAccessibilityService.beginClicking(pos[0], pos[1], cps);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true;
                        params.x = (int)(startX + dx);
                        params.y = (int)(startY + dy);
                        wm.updateViewLayout(bubble, params);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        ClickAccessibilityService.stopClicking();
                        return true;
                }
                return true;
            }
        });
        wm.addView(bubble, params);
    }

    private float[] center() {
        return new float[]{params.x + 38, params.y + 38};
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "SET_CPS".equals(intent.getAction())) {
            cps = Math.max(1, Math.min(100, intent.getIntExtra("cps", 100)));
        } else if (intent != null) {
            cps = Math.max(1, Math.min(100, intent.getIntExtra("cps", 100)));
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        ClickAccessibilityService.stopClicking();
        if (bubble != null) wm.removeView(bubble);
        stopForeground(true);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
