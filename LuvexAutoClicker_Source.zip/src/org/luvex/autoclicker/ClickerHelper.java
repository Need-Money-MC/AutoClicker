package org.luvex.autoclicker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.os.Build;
import android.view.accessibility.AccessibilityManager;
import android.content.ComponentName;

import org.kivy.android.PythonActivity;

public class ClickerHelper {
    private static int cps = 100;

    public static void requestPermissionsAndStart(int value) {
        cps = Math.max(1, Math.min(100, value));
        Activity a = PythonActivity.mActivity;
        if (a == null) return;
        if (!Settings.canDrawOverlays(a)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + a.getPackageName()));
            a.startActivity(i);
            return;
        }
        Intent s = new Intent(a, FloatingButtonService.class);
        s.putExtra("cps", cps);
        if (Build.VERSION.SDK_INT >= 26) a.startForegroundService(s);
        else a.startService(s);
        a.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    public static void setCps(int value) {
        cps = Math.max(1, Math.min(100, value));
        Activity a = PythonActivity.mActivity;
        if (a != null) {
            Intent i = new Intent(a, FloatingButtonService.class);
            i.setAction("SET_CPS");
            i.putExtra("cps", cps);
            a.startService(i);
        }
    }

    public static void stopOverlay() {
        Activity a = PythonActivity.mActivity;
        if (a != null) a.stopService(new Intent(a, FloatingButtonService.class));
    }
}
