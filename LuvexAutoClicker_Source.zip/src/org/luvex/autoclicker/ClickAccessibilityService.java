package org.luvex.autoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class ClickAccessibilityService extends AccessibilityService {
    static ClickAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() { stopClicking(); }
    @Override public void onDestroy() {
        stopClicking();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static void beginClicking(float x, float y, int cps) {
        if (instance != null) instance.startLoop(x, y, Math.max(1, Math.min(100, cps)));
    }
    public static void stopClicking() {
        if (instance != null) instance.handler.removeCallbacksAndMessages(null);
    }

    private void startLoop(final float x, final float y, final int cps) {
        stopClicking();
        final long interval = Math.max(10, 1000L / cps);
        final Runnable[] task = new Runnable[1];
        task[0] = new Runnable() {
            @Override public void run() {
                if (Build.VERSION.SDK_INT >= 24) {
                    Path p = new Path();
                    p.moveTo(x, y);
                    p.lineTo(x + 0.1f, y + 0.1f);
                    GestureDescription.StrokeDescription stroke =
                        new GestureDescription.StrokeDescription(p, 0, 1);
                    GestureDescription gesture = new GestureDescription.Builder()
                        .addStroke(stroke).build();
                    dispatchGesture(gesture, null, null);
                }
                handler.postDelayed(this, interval);
            }
        };
        handler.post(task[0]);
    }
}
