from kivy.app import App
from kivy.lang import Builder
from kivy.utils import platform
from kivy.clock import Clock

KV = r"""
#:import dp kivy.metrics.dp
BoxLayout:
    orientation: "vertical"
    padding: dp(22)
    spacing: dp(16)
    canvas.before:
        Color:
            rgba: 0.025, 0.035, 0.085, 1
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: "LUVEX AUTO CLICKER"
        font_size: "22sp"
        bold: True
        color: 0.92, 0.96, 1, 1
        size_hint_y: None
        height: dp(55)
    Label:
        text: "کنترل کلیک خودکار اندروید"
        color: 0.62, 0.69, 0.85, 1
        size_hint_y: None
        height: dp(30)
    Button:
        id: power
        text: "ON" if app.enabled else "OFF"
        font_size: "28sp"
        bold: True
        background_normal: ""
        background_color: (0, .72, .48, 1) if app.enabled else (.88, .20, .35, 1)
        size_hint_y: None
        height: dp(86)
        on_release: app.toggle()
    Label:
        text: "سرعت کلیک"
        color: .8, .85, 1, 1
        size_hint_y: None
        height: dp(28)
    Spinner:
        id: speed
        text: "100 CPS"
        values: ["40 CPS", "50 CPS", "75 CPS", "100 CPS"]
        size_hint_y: None
        height: dp(52)
        on_text: app.set_speed(self.text)
    Label:
        text: app.status
        color: .25, .92, .70, 1
        halign: "center"
        text_size: self.width, None
    Label:
        text: "روشن کن؛ سپس مجوزهای Overlay و Accessibility را فعال کن.\\nدکمه شناور را نگه دار تا همان نقطه کلیک شود؛ با رها کردن متوقف می‌شود."
        color: .65, .71, .85, 1
        halign: "center"
        valign: "middle"
        text_size: self.width, None
"""

class AutoClickerApp(App):
    enabled = False
    status = "خاموش"
    cps = 100

    def build(self):
        self.root = Builder.load_string(KV)
        return self.root

    def set_speed(self, value):
        try:
            self.cps = int(value.split()[0])
            if platform == "android" and self.enabled:
                self._call("setCps", self.cps)
        except Exception:
            pass

    def _call(self, method, *args):
        from jnius import autoclass
        Helper = autoclass("org.luvex.autoclicker.ClickerHelper")
        getattr(Helper, method)(*args)

    def toggle(self):
        if platform != "android":
            self.status = "این برنامه باید روی اندروید اجرا شود."
            return
        try:
            if not self.enabled:
                self._call("requestPermissionsAndStart", self.cps)
                self.enabled = True
                self.status = "فعال‌سازی شناور؛ مجوزهای اندروید را تأیید کن."
            else:
                self._call("stopOverlay")
                self.enabled = False
                self.status = "خاموش شد."
        except Exception as e:
            self.status = "خطا: " + str(e)

    def on_stop(self):
        if platform == "android" and self.enabled:
            try:
                self._call("stopOverlay")
            except Exception:
                pass

if __name__ == "__main__":
    AutoClickerApp().run()
